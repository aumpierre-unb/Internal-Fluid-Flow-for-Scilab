Internal Fluid Flow Toolbox
This package provides a set of functions designed to solve problems of internal
fluid flow. All functions are based on the Poiseuille condition for laminar
flow, the Colebrooke-White equation for turbulent flow, and the Darcy-Weisbach
equation for head loss. The simplest problems on internal flow consist in
computing either the Reynolds number or the Darcy friction factor given the
other and the relative roughness. For those cases, this package provides
functions epsf2Re and epsRe2f, respectively. More elaborated problems consist in
computing both the Reynolds number and the Darcy friction factor given the head
loss, the tube length, the fluid's density and dynamic viscosity, the
gravitational acceleration, the relative roughness and either the dynamic
diameter or the linear velocity or the volumetric flow. For those cases, this
package provides functions hDeps2fRe, hveps2fRe and hQeps2fRe, respectively. A
slightly more elaborate situation arises when roughness is given instead of
relative roughness along with the linear velocity or the volumetric flow.
For those cases, this package provides functions hvthk2fRe and hQthk2fRe,
respectively. All function in this package offer the option of plotting the
solution on a schematic Moody diagram. Enjoy!

TODO:
* Fix the spell of "Weissbach" to "Weisbach" in DESCRIPTION and
readme.txt
* Allow espfD2Re to compute Reynolds number for laminar flow and/or turbulent
flow, accordingly
* Set a default value eps=2e-3 to the second input argument in epsfD2Re and
epsRe2fD
* Include a fully rough line in plots
* 

inflowlib v0.0.3 (2022-07-09)
=============================
* First release
* Module under construction